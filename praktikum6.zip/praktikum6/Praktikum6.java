/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikum6;

/**
 *
 * @author ASUS
 */
public class Praktikum6 {

    public static void main(String[] args) {
        Produk p1 = new Produk("Laptop", 7000000, 15);
        Produk p2 = new Produk("Handphone",1500000, 15);
        
        System.out.println("Nama produk 1 : " + p1.nama);
        System.out.println("Harga produk 1 : " + p1.getHarga());
        
        p1.setHarga(5000000);
        System.out.println("Harga baru untuk produk 1 : " + p1.getHarga());
        
        System.out.println(p1.nama);
        System.out.println(p1.stok);
        //System.out.println(p1.harga);

        //p1.namaSupplier();
        p1.namaSupplierFix();
        p1.tampilkanInfo();
        p2.tampilkanInfo();
        
        Produk.infoJumlahProduk();
    }
}
