/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.praktikum6;
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class LatihanPraktikum6 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Bank bank1 = new Bank("112233");
        
        Bank.tampilkanIdBank();
        bank1.setNamaBank("BNI");
        System.out.println("Nama Bank : " + bank1.getNamaBank());
        System.out.println("======================================");
        System.out.print("Masukkan ID Rekening : ");
        String id = input.nextLine();
        System.out.print("Masukkan Nama Pemilik : ");
        String namaPemilik = input.nextLine();
        System.out.print("Masukkan Total Saldo terakhir : ");
        double saldo = input.nextDouble();
        
        Rekening rek1 = new Rekening(id, namaPemilik, saldo);
        System.out.println("======================================");
        rek1.tampilkanInfo();
        
        System.out.println("== Menu Rekening ==");
        System.out.println("1. Ganti ID");
        System.out.println("2. Ganti Nama");
        System.out.println("3. Tambah Saldo");
        System.out.println("4. Kurang Saldo");
        System.out.println("5. Tampilkan Info Rekening");
        System.out.println("6. Keluar");
        int pil;
        do{
        System.out.println("======================================");
        System.out.print("Masukkan pilihan : ");
        pil = input.nextInt();
        input.nextLine();
        switch(pil) {
            case 1 : 
                System.out.print("Masukkan ID baru : ");
                String idBaru = input.nextLine();
                rek1.setId(idBaru);
                System.out.println("ID sudah diperbarui");
            break;
            case 2 :
                System.out.print("Masukkan Nama Pemilik baru : ");
                String namaPemilikBaru = input.nextLine();
                rek1.setNamaPemilik(namaPemilikBaru);
                System.out.println("Nama Pemilik sudah diperbarui");
            break;
            case 3 : 
                System.out.print("Masukkan Jumlah Saldo : ");
                double saldoTambah = input.nextDouble();
                rek1.setTambahSaldo(saldoTambah);
                System.out.println("Saldo sudah ditambahkan");
            break;
            case 4 :
                System.out.print("Masukkan Jumlah Saldo : ");
                double saldoKurang = input.nextDouble();
                rek1.setKurangSaldo(saldoKurang);
                System.out.println("Saldo sudah dikurangi");
            break;
            case 5 :
                System.out.println("ID Pemilik : " + rek1.getId());
                System.out.println("Nama Pemilik : " + rek1.getNamaPemilik());
                System.out.println("Saldo : " + rek1.getSaldo());
            break;
            case 6 :
                System.out.println("Terimakasih, Program selesai");
            break;
            default :
                System.out.println("Pilihan tidak tersedia");
        } 
        } while (pil != 6);
    }
}
